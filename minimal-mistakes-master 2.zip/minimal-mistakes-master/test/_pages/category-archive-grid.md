---
title: "Posts by Category (grid view)"
layout: categories
permalink: /categories-grid/
entries_layout: grid
author_profile: true
---
